package com.example.runimprove

interface OnClickListener {

    fun onLongClick(entreno: Entreno)
}